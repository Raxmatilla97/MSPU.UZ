---
name: "🚨 Immediate Support"
about: 'I use October and it just broke! Help me!'
---

This repository is only for reporting reproducible bugs or problems. If you need support, please use the following options:

- Slack: https://octobercms.slack.com (Get an invite: https://octobercms-slack.herokuapp.com/)
- Live chat (IRC): https://octobercms.com/chat - **Note:** Not as active as Slack
- Forum: https://octobercms.com/forum
- Stack Overflow: https://stackoverflow.com/questions/tagged/octobercms

If you rely on OctoberCMS for your business consider purchasing a paid support plan, visit https://octobercms.com/premium-support

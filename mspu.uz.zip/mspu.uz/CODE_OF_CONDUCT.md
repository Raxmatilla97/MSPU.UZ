# Code of Conduct

We promise to extend courtesy and respect to everyone opening an issue. We expect anyone using the bug trackers to do the same.

All reported issues to this project are valuable. Please act with respect and avoid demeaning, condescending, racist, sexist and other inappropriate language and conduct. Please ensure comments stay professional and constructive.